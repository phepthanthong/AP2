#include "library.h"

using namespace std;

void workTicket(list <Cage> chuong, list <Animal> ani);
