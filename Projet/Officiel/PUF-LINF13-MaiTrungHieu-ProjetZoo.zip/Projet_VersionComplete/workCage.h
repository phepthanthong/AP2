#include "library.h"

using namespace std;

void workCage(list <Cage>& chuong, list <Animal> ani, list <Viande> &meat,
	      list <Legume> &vege, list <Ouvrier> & ouv, list <Zone> &zon);