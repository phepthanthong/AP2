#ifndef OURS_H
#define OURS_H

#include <iostream>
#include <string>
#include "omnivore.h"

using namespace std;

class Ours : public Omnivore {


 public:
  Ours();
  ~Ours();
  void initialise();


};

#endif

