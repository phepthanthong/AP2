#include "library.h"

using namespace std;

void workZone( list<Zone> & zon, list <Cage> &chuong);

