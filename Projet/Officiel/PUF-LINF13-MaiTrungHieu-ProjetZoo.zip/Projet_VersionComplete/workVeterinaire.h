#include "library.h"

using namespace std;

void workVeterinaire(list<Animal>& ani, VeterinaireGeneral &vet, Dentiste & dent, Chiropracteur & chiro);

