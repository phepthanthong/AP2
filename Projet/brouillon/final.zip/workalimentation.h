#include "library.h"

using namespace std;

void workAlimentation (list <Viande> &meat, list <Legume> & vege);
