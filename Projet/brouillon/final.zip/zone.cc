 #include "zone.h"

using namespace std;

int Zone::numZone = 0;

Zone::Zone()
{
  numZone++;
  nomZone = "Z-";
  nomZone.append(static_cast<ostringstream*>( &(ostringstream() << numZone) )->str());
  numberAnimal =0;
}
Zone::~Zone(){}

string Zone::getNom()
{
  return nomZone;
}
int Zone::compterAnimaux() {return numberAnimal;}

bool Zone::checkCage()
{
    return (listCage.size() != 0);
}
void Zone::addCage(string maCage)
{
  listCage.push_back(maCage);
  cout << "Dua Cage " << maCage << " vao zone: " << nomZone << " thanh cong\n";
}

void Zone::deleteCage(string maCage)
{
  list<string>::iterator it_Cage;
  for(it_Cage = listCage.begin(); it_Cage != listCage.end(); it_Cage++)
    if(maCage == *it_Cage)
    {
      listCage.remove(maCage);
      cout << "Da xoa thanh cong Cage " << maCage <<" khoi Zone " << nomZone <<endl;
      break;
    }
  if(it_Cage == listCage.end())
    cout << "Khong co Cage nay trong Zone" <<endl;
}

void Zone::increase() {numberAnimal++;}

void Zone::decrease() {numberAnimal--;}

void Zone::showZone()
{
  cout << "Zone: " << nomZone << " \t\tTong so Animal:  " << numberAnimal <<endl;
  if (listCage.size() == 0)
    cout << "\t\t Chua co Cage nao trong Zone \n";
  else
  {
    cout << "\t\tBao gom Cage:  ";
    list<string>::iterator it_Cage;
    for(it_Cage = listCage.begin(); it_Cage != listCage.end(); it_Cage++)
    {
      cout << *it_Cage << "    "; 
    }
    cout << endl;
  }
  
}

