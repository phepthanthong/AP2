#include "fonction_list_cage.h"

using namespace std;

void show_list_cage(list <Cage> chuong)
{
  list <Cage>::iterator it_Cage;
  if (chuong.size() == 0)
	  cout << "Chua co chuong nao" << endl;
	else
	{
	  cout << "Co cac chuong: \n";
	  for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	  {
	    cout <<"\t\t\t" << (*it_Cage).get_numCage() << "\t" ;
	    if( (*it_Cage).compterAnimaux()==0) cout << "Empty \t";
	    else cout << "Da co Animal \t";
	    if( (*it_Cage).get_take_care()=="NULL") cout <<"Chua co nhan vien cham soc\n";
	    else cout << "Da co nhan vien cham soc\n";
	  }
	}
}

void show_detail_cage(list <Cage> chuong)
{
  list <Cage>::iterator it_Cage;
  string maCage;
	cout << endl <<"Nhap ma Cage muon xem thong tin chi tiet: " ;
	cin >> maCage;
	for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	{
	  if((*it_Cage).get_numCage() == maCage)
	  {
	    (*it_Cage).showCage();
	    break;
	  }
	}
	if (it_Cage == chuong.end())
	  cout <<"Khong co chuong ban can tim" <<endl;
}

void create_cage (list <Cage> &chuong,  list<Zone> & zon)
{
  list <Cage>::iterator it_Cage;
  list <Zone>::iterator it_Zone;
	if (zon.size() == 0)
	  cout <<"Chua co Zone nao, yeu cau ban phai tao Zone truoc khi tao Cage \n";
	else
	{
	  string nameZone;
	  bool check=false;
	  Cage cg;
	  cout <<"Tao thanh cong Cage " << cg.get_numCage() <<endl;
	  do{
	    cout << "Danh sach zone:  ";
	    for(it_Zone = zon.begin(); it_Zone != zon.end(); it_Zone++)
	      cout << (*it_Zone).getNom() << "    ";
	    cout <<endl << "Nhap vao Zone ma Cage muon de vao: "; cin >> nameZone;
	    for(it_Zone = zon.begin(); it_Zone != zon.end(); it_Zone++)
	      if ((*it_Zone).getNom() == nameZone)
	      {
		check = true;
		cg.setZone(nameZone);
		(*it_Zone).addCage(cg.get_numCage());
		chuong.push_back(cg);
		break;
	      }
	    if(it_Zone == zon.end())
	      cout << "Zone nay khong hien huu, vui long chon lai Zone \n";
	  }while ( check == false);
	}
}

void delete_cage(list <Cage> &chuong, list <Ouvrier> &ouv, list<Zone> & zon)
{
  list <Zone>::iterator it_Zone;
  list <Cage>::iterator it_Cage;
	string nameZone;
	string maCage;
	if(chuong.size()==0)
	  cout << "List Cage empty"<< endl;
	else
	{
	  cout << "Ma Cage ban muon loai khoi danh sach: ";
	  cin >> maCage;
	  for(it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	    {
	      if (maCage == (*it_Cage).get_numCage())
		{
		  if ((*it_Cage).compterAnimaux()==0)
		  {
		    nameZone = (*it_Cage).getZone();
		    for(it_Zone = zon.begin(); it_Zone != zon.end(); it_Zone++)
		      if ((*it_Zone).getNom() == nameZone)
			(*it_Zone).deleteCage(maCage);
		    deactivate(ouv, maCage);
		    chuong.erase(it_Cage);
		    cout << "Da xoa Cage thanh cong" <<endl;
		  }
		  else
		    cout << "Chuong dang co Animal, khong huy duoc" << endl;
		  break;
		}
	    }
	  if (it_Cage == chuong.end())
	    cout << "Khong co Cage ban can xoa " << endl;
	}
}

