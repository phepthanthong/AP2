#include "library.h"
#include "workalimentation.h"
#include "workEmploye.h"
#include "workCage.h"
#include "workAnimal.h"
#include "workZone.h"
#include "workTicket.h"
#include "workVeterinaire.h"

using namespace std;


int main()
{
  list <Cage> chuong;
  list <Ouvrier> ouv;
  list <Animal> ani;
  list <Viande> meat;
  list <Legume> vege;
  list <Zone> zon;
  VeterinaireGeneral vet;
  Chiropracteur chiro;
  Dentiste dent;
  Zoo sothu;
  sothu.initialiseZoo();
  sothu.showZoo();
  char choice;
  do{
    menu_main();
    cin >> choice;
    cout << endl;
    switch (choice)
    {
      case '1':
      {
	sothu.showZoo();
	cout << endl << "\tCo " << zon.size() << " Zone" <<endl;
	cout << "\tCo " << chuong. size() << " Cage" << endl;
	cout << "\tCo " << sothu.compterAnimaux(ani) << " Animal" <<endl;
	cout << "\tCo " << ouv.size() << " Nhan vien cham soc chuong thu" << endl;
	cout << "\tCo " << meat.size()+vege.size() << " thuc an gom: " << meat.size();
	cout << " la thit va " << vege.size() << " la rau cu qua" << endl;
	break;
      }
      case '2':
      {
	workZone(zon, chuong);
	break;
      }
      case '3':
      {
	workCage(chuong, ani,  meat, vege, ouv,zon);
	break;
      }
      case '4':
      {
	workAnimal(ani, chuong, zon, vet, chiro);
	break;
      }
      case '5': // van con loi o cho nhap vao khac voi ky tu so (nho sua)
      {
	workAlimentation(meat, vege);
	break;
      }
      case '6':
      {
	workEmploye(chuong, ouv); // truyen them list Cage vao de khi xoa thi Cage do khong co nguoi lam viec
	break; // hay la khi thiet lap nhan vien do lam o chuong nao, kiem tra chuong do co hien huu khong
      }
      case '7':
      {
	workTicket(chuong, ani);
	break;
      }
      case '8':
      {
	workVeterinaire(ani,vet, dent, chiro);
	break;
      }
      case '9':
      {
	cout << "Cam on ban da su dung chuong trinh, hen ngay gap lai " << endl << "Chuong trinh ket thuc" <<endl;
	break;
      }
      default:
      {
	cout << "Nhap sai... Vui long nhap lai tu 1 cho den 7 " << endl;
	break;
      }
    }
  }while(choice!='9');
 }
