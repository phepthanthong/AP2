 #include "omnivore.h"

Omnivore::Omnivore(){}

Omnivore::~Omnivore(){}

string Omnivore::loai_thu()
{
  name="OMNIVORE";
  return name;
}
