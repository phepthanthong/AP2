#include <stdio.h>
#include <cstdlib>
#include <iostream>
#include <string>
#include <list>

#include "enter_value.h"
#include "fonction_list_meat.h"
#include "fonction_list_vege.h"
#include "fonction_list_ouvrier.h"
#include "fonction_list_animal.h"
#include "fonction_list_cage.h"
#include "employe.h"
#include "ouvrier.h"
#include "animal.h"
#include "ticket.h"
#include "animal_tiger.h"
#include "animal_lion.h"
#include "animal_elephant.h"
#include "animal_ours.h"
#include "cage.h"
#include "menu.h"
#include "zone.h"
#include "veterinaire_General.h"
#include "dentiste.h"
#include "chiropracteur.h"

#include "zoo.h"
#include "alimentation.h"
#include "viande.h"
#include "legume.h"
using namespace std;