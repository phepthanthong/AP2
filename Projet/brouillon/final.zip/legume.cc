#include "legume.h"

Legume::Legume()
{
  calorieLegume = 0;
  nomLegume = "NULL";
}

Legume::~Legume(){}




void Legume::valueLegume()
{
  cout << "Enter name of the Legume: ";
  cin >> nomLegume;
  cout << "How much it content in calorie? : ";
  do{
    scanf("%d", &calorieLegume);
    if (calorieLegume== 0) cout << "Nhap sai, vui long nhap lai: ";
    cin.ignore();
  }while (calorieLegume == 0);
  cout << "Weight of the " << nomLegume << " ?: ";
  do{
    scanf("%d", &quantityLegume);
    if (quantityLegume == 0) cout << "Nhap sai, vui long nhap lai: ";
    cin.ignore();
  }while (quantityLegume == 0);
}

void Legume::show_info()
{
  cout << "\tNom de l'Aliment: " << nomLegume << endl;
  cout << "\tIl contient " << calorieLegume << " calorie" << endl;
  cout << "\tKhoi luong rau cu qua: "<< quantityLegume << "kg" <<endl; 
}

int Legume::get_quantityLegume()
{
  return quantityLegume;
}
void Legume::importLegume(int a)
{
  quantityLegume +=a;
}

void Legume::exportLegume(int a)
{
  quantityLegume -=a;
}