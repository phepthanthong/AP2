#include "animal.h"

int Animal::numAnimal = 0;
Animal::Animal(){}

Animal::~Animal(){}

string Animal::getNomAnimal()
{
  return nomAnimal;
}

string Animal::getNumero()
{
  return codeAnimal;
}
string Animal::getType()
{
  return type;
}
string Animal::getChungloai()
{
  return quelType;
}
string Animal::getCage ()
{
  return cage;
}
string Animal::get_malade() {return malade;}
void Animal::set_malade(string mal)
{
  malade = mal;
}
void Animal::change_Cage(string maCage)
{
  cage = maCage;
}
void Animal::visiterMedicale(VeterinaireGeneral &vet)
{
  int random;
  random = rand()%5+1;
  if (random <=2)
  {
    random = rand()%2+1;
    if(random == 1) 
    {
      malade="DENTISTE";
    }
    else malade="CHIROPRACTEUR";
    vet.set_malade(codeAnimal,malade);
  }
  else malade="NULL";
}

void Animal::parler()
{
  cout << endl;
  cout << "\t - Son numero: " << codeAnimal << endl;
  cout << "\t\t - Nom de l'animal: " << nomAnimal << endl;
  cout << "\t\t - Son type: " << type << endl;
  cout << "\t\t - Chung loai: " << quelType << endl;
  cout << "\t\t - Ngay sinh: " << dateNais << endl;
  cout << "\t\t - Chuong: " << cage << endl;
  if(malade=="NULL") cout << "\t\t - Tinh trang suc khoe: Tot" << endl;
  else cout << "\t\t - Tinh trang suc khoe: Benh" << endl;
  cout << endl;
}

