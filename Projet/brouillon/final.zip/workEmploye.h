#include "library.h"

using namespace std;

void workEmploye( list <Cage> &chuong, list <Ouvrier> & ouv);
