#include "viande.h"

Viande::Viande()
{
  calorieViande = 0;
  quantityViande = 0;
  nomViande = "NULL";
}

Viande::~Viande(){}

void Viande::valueViande()
{
  cout << "Enter name of the meat: ";
  cin >> nomViande;
  cout << "How much it content in calorie? : ";
  enter_value(calorieViande);
  cout << "Weight of the " << nomViande << " ?: ";
  enter_value(quantityViande);
}
void Viande::show_info()
{
  cout << "\tNom de l'Aliment: " << nomViande << endl;
  cout << "\tIl contient " << calorieViande << " calorie" << endl;
  cout << "\tKhoi luong thit: "<< quantityViande << "kg" <<endl; 
}

int Viande::get_quantityViande()
{
  return quantityViande;
}
void Viande::importViande(int a)
{
  quantityViande +=a;
}

void Viande::exportViande(int a)
{
  quantityViande -=a;
}





