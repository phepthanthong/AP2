#include "fonction_list_meat.h"


/*======================= list thit =======*/
void show_list_viande(list <Viande>  meat)
{
  list<Viande>::iterator it_viande;
  if(meat.size()==0)
    cout << "khong co thit"<< endl;
  else
  {
    int sothutu=1;
    for(it_viande = meat.begin(); it_viande != meat.end(); it_viande++)
    {
      cout << sothutu << ")\t";
      (*it_viande).show_info();
      sothutu++;
    }
  }
}

void add_list_viande (Viande moi ,list <Viande> & meat)
{
  meat.push_back(moi);
  cout << "Nhap thit moi thanh cong" <<endl;
}

void nhap_thit (int vitri, int khoiluong, list <Viande> & meat)
{
  list<Viande>::iterator it_viande;
  for(it_viande = meat.begin(); it_viande != meat.end(); it_viande++)
    {
      vitri--;
      if (vitri==0)
      {
	(*it_viande).importViande(khoiluong);
	cout << "Ban da nhap thanh cong " <<endl;
	break;
      }
    }
    if (it_viande == meat.end())
      cout << "Nhap thit sai" <<endl;
}
void xuat_thit (int vitri, int khoiluong, list <Viande> & meat)
{
  list<Viande>::iterator it_viande;
  for(it_viande = meat.begin(); it_viande != meat.end(); it_viande++)
    {
      vitri--;
      if (vitri==0)
      {
	if ((*it_viande).get_quantityViande() >= khoiluong)
	{
	  (*it_viande).exportViande(khoiluong);
	  cout << " Cho thu an thanh cong" <<endl;
	  break;
	}
	else
	{
	  cout << "Thuc an ban chon khong du khoi luong" << endl;
	  break;
	}
      }
    }
  if (it_viande == meat.end())
      cout << "Nhap thit sai" <<endl;
}