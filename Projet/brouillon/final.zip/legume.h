#ifndef LEGUME_H
#define LEGUME_H

#include <iostream>
#include <string>
#include <stdio.h>
#include "alimentation.h"
using namespace std;

class Legume: public Alimentation {
 private:
  string nomLegume;
  int calorieLegume;
  int quantityLegume;

 public:
  Legume();
  ~Legume();

  void valueLegume();
  int get_quantityLegume();
  void importLegume(int a);
  void exportLegume(int a);
  void show_info();

};

#endif
