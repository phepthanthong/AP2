#include <iostream>
#include <stdio.h>
using namespace std;

void enter_value(int & number);

