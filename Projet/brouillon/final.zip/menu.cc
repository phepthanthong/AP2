#include "menu.h"

using namespace std;

void menu_main()
{
  cout << endl;
  cout << "\t1. Xem thong tin cua so thu " << endl;
  cout << "\t2. Xu ly Zone " << endl;
  cout << "\t3. Xu ly Cage " << endl;
  cout << "\t4. Xu ly Animal" << endl;
  cout << "\t5. Xu ly Alimentation " << endl;
  cout << "\t6. Xu ly Ouvrier " << endl;
  cout << "\t7. Ban Ticket " << endl;
  cout << "\t8. Veterinaire" << endl;
  cout << "\t9. Thoat " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_zone()
{
  cout << endl;
  cout << "\t1. Xem danh sach Zone " << endl;
  cout << "\t2. Add Zone" << endl;
  cout << "\t3. Delete Zone " << endl;
  cout << "\t4. Clear screen" << endl;
  cout << "\t5. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_cage()
{
  cout << endl;
  cout << "\t1. Xem danh sach Cage " << endl;
  cout << "\t2. Xem thong tin Cage " << endl;
  cout << "\t3. Add cage" << endl;
  cout << "\t4. Delete Cage " << endl;
  cout << "\t5. Cho thu trong chuong an" << endl;
  cout << "\t6. Clear screen" << endl;
  cout << "\t7. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_animal()
{
  cout << endl;
  cout << "\t1. Xem danh sach Animal " << endl;
  cout << "\t2. Xem thong tin theo Animal " << endl;
  cout << "\t3. Xem thong tin theo Cage " << endl;
  cout << "\t4. Add Animal" << endl;
  cout << "\t5. Delete Animal" << endl;
  cout << "\t6. Visiter Medicale" << endl;
  cout << "\t7. Doi chuong cho Animal" << endl;
  cout << "\t8. Clear screen" << endl;
  cout << "\t9. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_alimentation()
{
  cout << endl;
  cout << "\t1. Xem danh sach Thit " << endl;
  cout << "\t2. Xem danh sach Rau " << endl;
  cout << "\t3. Nhap thit" << endl;
  cout << "\t4. Nhap rau" << endl;
  cout << "\t5. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_ouvrier()
{
  cout << endl;
  cout << "\t1. Xem danh sach Nhan vien" << endl;
  cout << "\t2. Xem thong tin chi tiet nhan vien " << endl;
  cout << "\t3. Add nhan vien moi" << endl;
  cout << "\t4. Delete Nhan Vien" << endl;
  cout << "\t5. Thiet lap noi lam viec cho nhan vien" << endl;
  cout << "\t6. Clear screen" << endl;
  cout << "\t7. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_list_animal()
{
    cout << endl;
  cout << "\t1. Lion" << endl;
  cout << "\t2. Tiger " << endl;
  cout << "\t3. Elephant" << endl;
  cout << "\t4. Ours" << endl;
  cout << "\t5. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";  
}

void menu_ticket()
{
  cout << endl;
  cout << "\t1. Ban ve \n";
  cout << "\t2. Xem lai thong tin \n";
  cout << "\t3  Dong y in\n";
  cout << "\t4  Huy Ticket va quay ve menu chinh \n";
  cout << "\t5. Xem ket qua hoat dong\n";
  cout << "\t6. Clear screen\n";
  cout << "\t7. Quay ve menu truoc\n\n";
  cout << "\t\tLua chon cua ban: "; 
  
}

void menu_veterinaire()
{
  cout << endl;
  cout << "\t1. Veterinaire General \n";
  cout << "\t2. Send to Doctor Special \n";
  cout << "\t3  Dentiste\n";
  cout << "\t4  Dentiste chua benh \n";
  cout << "\t5. Chiropracteur\n";
  cout << "\t6. Chiropracteur chua benh\n";
  cout << "\t7. Clear screen\n";
  cout << "\t8. Quay ve menu truoc\n\n";
  cout << "\t\tLua chon cua ban: "; 
  
}