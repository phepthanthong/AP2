#include <iostream>

using namespace std;

void menu_main();

void menu_zone();

void menu_cage();

void menu_animal();

void menu_alimentation();

void menu_ouvrier();
void menu_list_animal();

void menu_ticket();
void menu_veterinaire();
