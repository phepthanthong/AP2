
#include "library.h"
#include "workalimentation.h"
#include "workEmploye.h"
#include "workCage.h"
#include "workAnimal.h"

using namespace std;


int main()
{
  list <Cage> chuong;
  list <Ouvrier> ouv;
  list <Animal> ani;
  list <Viande> meat;
  list <Legume> vege;
  Zoo sothu;
  sothu.initialiseZoo();
  sothu.showZoo();
  char choice;
  do{
    menu_main();
    cin >> choice;
    switch (choice)
    {
      case '1':
      {
	sothu.showZoo();
	break;
      }
      case '2':
      {
	workCage(chuong, ani,  meat, vege);
	break;
      }
      case '3':
      {
	workAnimal(ani, chuong);
	break;
      }
      case '4': // van con loi o cho nhap vao khac voi ky tu so (nho sua)
      {
	workAlimentation(meat, vege);
	break;
      }
      case '5':
      {
	workEmploye(chuong, ouv); // truyen them list Cage vao de khi xoa thi Cage do khong co nguoi lam viec
	break; // hay la khi thiet lap nhan vien do lam o chuong nao, kiem tra chuong do co hien huu khong
      }
      case '6':
      {
	cout << "Cam on ban da su dung chuong trinh, hen ngay gap lai " << endl << "Chuong trinh ket thuc" <<endl;
	break;
      }
      default:
      {
	cout << "Nhap sai... Vui long nhap lai tu 1 cho den 6 " << endl;
	break;
      }
    }
  }while(choice!='6');
  /*
  Cage moi;
  moi.afficher();
  chuong.push_back(moi);
  Cage hai;
  hai.afficher();
  
  show_list_viande (meat);
  Viande heo("heo",2000,500);
  add_list_viande (heo,meat);
  show_list_viande(meat);
  hai.faireManger(meat);
  show_list_viande(meat);
  
  
  
 
  Zoo a("Foret africane","415 rue Jean-Michel",83254);
  cout << a << endl;
  
  list <Viande> meat;
  show_list_viande (meat);
  Viande heo("heo",2000,500);
  add_list_viande (heo,meat);
  show_list_viande(meat);
  Viande ga("ga",1000,557);
  add_list_viande (ga,meat);
  show_list_viande(meat);
  nhap_thit (1, 300, meat);
  xuat_thit (2, 200, meat);
  show_list_viande(meat);
  // Employe *d = new Ouvrier("Lam",2);
  //d->jeSuis();
 // delete d;
  //d = new Ouvrier("Minh",1);
 // d->jeSuis();
  //delete d;
  */
  /*
  Zoo a;
  a.afficher();
  Zoo b("hieu","ndc",123456789);
  b.afficher();

  Employe *c = new Ouvrier();
  c->jeSuis();
  Employe *d = new Ouvrier("Lam");
  d->jeSuis();
  
  Cage f("moyenne");
  f.afficher();

  Animal *g = new Lion();
  g->afficherA();
  Animal *h = new Lion("Baby");
  h->afficherA();
  Animal *i = new Tigre();
  i->afficherA();
  Animal *k = new Tigre("Justine");
  k->afficherA();
  Animal *p = new Elephant();
  p->afficherA();
  Animal *q = new Elephant("Micheal");
  q->afficherA();

  Alimentation *l = new Viande();
  l->affiAliment();
  Alimentation *m = new Viande("Boeuf",150);
  m->affiAliment();
  Alimentation *n = new Legume();
  n->affiAliment();
  Alimentation *o = new Legume("Salade",20);
  o->affiAliment();
  */

  
 }
