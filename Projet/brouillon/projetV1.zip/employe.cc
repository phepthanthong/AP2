#include "employe.h"


int Employe::numEmploye = 0;
Employe::Employe()
{
  cout << " == Constructeur par Defaut: Employe" << endl;

}

Employe::~Employe()
{
  cout << " == Destructeur: Employe" << endl;
}

Employe::Employe(string nom, string leMetier)
{
 cout << " == Constructeur avec parametre: Employe" << endl;
 
}
string Employe::getNom()
{

}
int Employe::getNum()
{

}



void Employe::jeSuis()
{
 
}
