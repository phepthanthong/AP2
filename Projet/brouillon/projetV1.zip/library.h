#include <cstdlib>
#include <iostream>
#include <string>
#include <list>

#include "fonction_list_meat.h"
#include "fonction_list_vege.h"
#include "fonction_list_ouvrier.h"
#include "fonction_list_animal.h"
#include "employe.h"
#include "ouvrier.h"
#include "animal.h"
//#include "carnivore.h"
#include "animal_tiger.h"
#include "animal_lion.h"
#include "cage.h"
#include "menu.h"

#include "zoo.h"
#include "alimentation.h"
#include "viande.h"
#include "legume.h"
using namespace std;