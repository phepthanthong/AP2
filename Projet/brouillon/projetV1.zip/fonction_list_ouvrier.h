#ifndef HAMLIST_OUVRIER
#define HAMLIST_OUVRIER

#include <list>
#include <iostream>
#include <string.h>
#include "ouvrier.h"
#include "cage.h"
//#include "alimentation.h"

using namespace std;



void show_list_Ouvrier(list <Ouvrier>  worker);
void show_Ouvrier(int maNV ,list <Ouvrier>  worker);
void add_list_Ouvrier(Ouvrier &moi ,list <Ouvrier> & worker);
void changer_cage_Ouvrier (int maCage, int vitri, list <Ouvrier> & worker, list<Cage> chuong);
void change_status_Ouvrier (int maCage, list <Ouvrier> & worker);
void deleteOuvrier(int maNV, list <Ouvrier> & worker);
//void nhap_thit (int vitri, float khoiluong, list <Ouvrier> & meat);
//void xuat_thit (int vitri, float khoiluong, list <Ouvrier> & meat);




#endif
