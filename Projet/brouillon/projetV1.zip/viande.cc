#include "viande.h"

Viande::Viande()
{
  cout << " == Constructeur par defaut: Viande" << endl;
  calorieViande = 0;
  nomViande = "NULL";
}

Viande::~Viande()
{
  cout << " == Destructeur: Viande" << endl;
}

void Viande::valueViande()
{
  cout << "Enter name of the meat: ";
  cin >> nomViande;
  cout << "How much it content in calorie? : ";
  cin >> calorieViande;
  cout << "Weight of the " << nomViande << " ?: ";
  cin >> quantityViande;
}
void Viande::show_info()
{
  cout << "\tNom de l'Aliment: " << nomViande << endl;
  cout << "\tIl contient " << calorieViande << " calorie" << endl;
  cout << "\tKhoi luong thit: "<< quantityViande << "kg" <<endl; 
}

float Viande::get_quantityViande()
{
  return quantityViande;
}
void Viande::importViande(float a)
{
  quantityViande +=a;
}

void Viande::exportViande(float a)
{
  quantityViande -=a;
}





