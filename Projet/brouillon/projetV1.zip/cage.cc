#include "cage.h"

int Cage::numCage = 0;
Cage::Cage()
{
  cout << " == Constructeur par Defaut: Cage" << endl;
  numCage++;
  maCage = "C-";
  maCage.append(static_cast<ostringstream*>( &(ostringstream() << numCage) )->str());
  type="NULL";
 // cout << ouv << endl;
}

Cage::~Cage()
{
  cout << " == Destructeur: Cage" << endl;
}

/*void Cage::faireManger(list <Viande> & meat, list <Legume> & vege)
{
  if (ani.front().getChungloai()=="CARNIVORE")
  {
    int sothutu;
    float khoiluong;
    show_list_viande(meat);
    cout << "Nhap so thu tu: "; cin >> sothutu;
    cout << "Nhap vao khoi luong: "; cin >> khoiluong;
    xuat_thit (sothutu, khoiluong, meat);
  }
  else if (ani.front().getChungloai()=="HERBIVORE")
    {
    int sothutu;
    float khoiluong;
    show_list_Legume(vege);
    cout << "Nhap so thu tu: "; cin >> sothutu;
    cout << "Nhap vao khoi luong: "; cin >> khoiluong;
    xuat_rau (sothutu, khoiluong, vege);
  }
  else
    cout << "Chuong khong co thu, khoi cho an" << endl;
}*/
void Cage::faireManger(list <Viande> & meat, list <Legume> & vege)
{
  if (getChungloai()=="CARNIVORE")
  {
    int sothutu;
    float khoiluong;
    show_list_viande(meat);
    cout << "Nhap so thu tu: "; cin >> sothutu;
    cout << "Nhap vao khoi luong: "; cin >> khoiluong;
    xuat_thit (sothutu, khoiluong, meat);
  }
  else if (getChungloai()=="HERBIVORE")
    {
    int sothutu;
    float khoiluong;
    show_list_Legume(vege);
    cout << "Nhap so thu tu: "; cin >> sothutu;
    cout << "Nhap vao khoi luong: "; cin >> khoiluong;
    xuat_rau (sothutu, khoiluong, vege);
  }
  else
    cout << "Chuong khong co thu, khoi cho an" << endl;
}
string Cage::getChungloai()
{
  return chungloai;
}
void Cage:: setChungloai(string cl)
{
  chungloai=cl;
}
string Cage::get_numCage()
{
  return maCage;
}
void Cage::setType(string loai)
{
  type=loai;
}
string Cage::getType()
{
  return type;
}
void Cage::showCage()
{

  cout << "Numero de Cage: " << maCage << endl;
  if(type =="NULL")
    cout << "khong co con thu nao ca"<< endl;
  else
    cout << "Cage dang chua: " << type <<endl;
  cout << endl;
  //cout << "Sa taille: " << taille << endl;
}
/*void Cage::emptyCage()
{
  list<Animal>::iterator it_Animal;
  if(ani.size()==0)
    cout << "khong co con thu nao ca"<< endl;
  else
  {
    for(it_Animal = ani.begin(); it_Animal != ani.end(); it_Animal++)
    {
	ani.erase(it_Animal);     
    }
    cout << "Da xoa toan bo danh sach thu thanh cong" <<endl;
  }
}
void Cage::import_Animal( Animal moi)
{
  ani.push_back(moi);
  cout << "Thu dua vao list thanh cong" <<endl;
}

list<Animal> Cage::getAnimal()
{
  return ani;
}
void Cage::changerAnimal(Cage & chuong)
{
  Animal temp;
  list<Animal> dongvat;
  list<Animal>::iterator it_Animal;
  cout << "test" <<endl;
  for(it_Animal = ani.begin(); it_Animal != ani.end(); it_Animal++)
    {
      temp=(*it_Animal);
      dongvat.push_back(temp);
      cout << "test" <<endl;
    }
  emptyCage();
  for(it_Animal = chuong.getAnimal().begin(); it_Animal != chuong.getAnimal().end(); it_Animal++)
    {
      temp=(*it_Animal);
      ani.push_back(temp);
      cout << "test" <<endl;
    }
  chuong.emptyCage();
  for(it_Animal = dongvat.begin(); it_Animal != dongvat.end(); it_Animal++)
    {
      temp=(*it_Animal);
      chuong.getAnimal().push_back(temp);
      cout << "test" <<endl;
    }
  
  cout << "Da doi cho thu cua 2 chuong thanh cong" << endl;
  
  
  
  
  
}*/




