#include "fonction_list_animal.h"


/*======================= list thu =======*/
void show_list_Animal(list <Animal>  ani, list <Cage> chuong)
{
  list<Animal>::iterator it_Animal;
  list<Cage>::iterator it_Cage;
  if(chuong.size() == 0)
    cout <<" So Thu chua co chuong " << endl;
  else
  {
    for(it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
    {
      cout << "Cage:  " << (*it_Cage).get_numCage() << endl;
      if (ani.size() == 0)
	cout << "\tChuong khong co thu" << endl;
      else
      {
	for(it_Animal = ani.begin(); it_Animal != ani.end(); it_Animal++)
	{
	  if( (*it_Cage).get_numCage() == (*it_Animal).getCage())
	    //cout << (*it_Animal).getNumero() << "\t";
	  (*it_Animal).parler();
	}
	cout <<endl <<endl;
      }
    }
  }
}
void show_info_Animal (list <Animal>  ani)
{
  string maAnimal;
  list<Animal>::iterator it_Animal;
  cout << "Nhap vao ma Animal de biet thong tin: ";
  cin.ignore();
  getline(cin, maAnimal);

    for(it_Animal = ani.begin(); it_Animal != ani.end(); it_Animal++)
      {
	if(maAnimal == (*it_Animal).getNumero())
	{
	  (*it_Animal).parler();
	  break;
	}
      }
    if(it_Animal == ani.end())
      cout << "Ma Animal sai" <<endl;
  
  
}
void add_list_Animal (Animal moi ,list <Animal> & ani, list <Cage> & chuong)
{
  string maCage;
  list<Cage>::iterator it_Cage;
  cout << endl << "Nhung chuong co kha nang chua Animal nay: " << endl;
  for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
  {
    if ((*it_Cage).getType() == moi.getType() || 
      (*it_Cage).getType() == "NULL")
      cout << (*it_Cage).get_numCage() << "\t" ;
  }
  bool check=false;
  cout << endl << "Chon Cage de dua thu vao: "; 
    do{
  getline(cin, maCage);
  for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
  {
    if (maCage == (*it_Cage).get_numCage() &&((*it_Cage).getType() == moi.getType() || 
      (*it_Cage).getType() == "NULL"))
    {
      moi.change_Cage (maCage);
      check=true;
      break;
    }
  }
  }while(check==false);
  ani.push_back(moi);
  (*it_Cage).setType(moi.getType());
  (*it_Cage).setChungloai(moi.getChungloai());
    cout << "Da add animal thanh cong " << endl;
}

void delete_list_Animal (string maAnimal,list <Animal> &ani, list <Cage> & chuong)
{
  int check=0;
  bool test=false;
  string maCage;
  list<Animal>::iterator it_Animal;
  list<Cage>::iterator it_Cage;
  for(it_Animal = ani.begin(); it_Animal != ani.end(); it_Animal++)
    {
	if(maAnimal == (*it_Animal).getNumero())
	{
	  maCage=(*it_Animal).getCage();
	  ani.erase(it_Animal);
	  test=true;
	  cout << "Xoa animal thanh cong" <<endl;
	  break;
	}
    }
  if(test)
  {
  for(it_Animal = ani.begin(); it_Animal != ani.end(); it_Animal++)
  {
    if(maCage == (*it_Animal).getCage())
    {
      check++;
      break;
    }
  }
  if(check ==0)
  {
    for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
    {
      if((*it_Cage).get_numCage() == maCage)
      {
	(*it_Cage).setType("NULL");
	break;
      }}}}
  else
    cout << "Khong co Animal can xoa" <<endl;
}
void chang_place (list <Animal> &ani, list <Cage> & chuong)
{
  string maCage1, maCage2,type1,type2;
  list<Animal>::iterator it_Animal;
  list<Cage>::iterator it_Cage;
  cout << "Danh sach cac Cage: ";
  for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
  {
    cout << (*it_Cage).get_numCage() << "\t";
  }
  cout <<"\nNhap ma so 2 Cage muon doi Animal\n";
  cout <<"Cage 1: "; cin >> maCage1; cout << maCage1 <<endl;
  cout <<"Cage 2: "; cin >> maCage2; cout << maCage2 << endl;
  for(it_Animal = ani.begin(); it_Animal != ani.end(); it_Animal++)
  {
    if(maCage1 == (*it_Animal).getCage())
    {
      (*it_Animal).change_Cage(maCage2);
      type2=(*it_Animal).getType();
    }
    else if (maCage2 == (*it_Animal).getCage())
    {
      (*it_Animal).change_Cage(maCage1);
      type1=(*it_Animal).getType();
    }
  }
  for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
  {
    if((*it_Cage).get_numCage() == maCage1)
      (*it_Cage).setType(type1);
    else if((*it_Cage).get_numCage() == maCage2)
      (*it_Cage).setType(type2);
      
  }
}


