#include "workalimentation.h"


void workAlimentation (list <Viande> &meat, list <Legume> & vege)
{
  int chose;
  system("clear");
  do
  {
    menu_alimentation();
    cin >> chose;
    switch (chose)
    {
      case 1:
      {
	show_list_viande(meat);
	break;
      }
      case 2:
      {
	show_list_Legume(vege);
	break;
      }
      case 3:
      {
	int luachon;
	cout <<" Ban muon nhap vao loai thit moi hay thit da co trong kho thuc an? " <<endl;
	cout <<" Bam '1' de nhap loai thit moi, '2' cho loai thit da co, Phim khac de quay tro lai munu truoc " <<endl;
	cout <<" \tLua chon cua ban: ";
	cin >> luachon;
	if (luachon == 1)
	{
	  Viande thit;
	  thit.valueViande();
	  add_list_viande (thit ,meat);
	}
	else if (luachon == 2)
	{
	  int sothutu;
	  float weight;
	  cout << " So thu tu cua thit muon nhap vao: ";
	  cin >> sothutu;
	  cout << " Khoi luong thit muon nhap them: ";
	  cin >> weight;
	  nhap_thit (sothutu, weight, meat);  
	}
	
	break;
      }
      case 4:
      {
	int luachon;
	cout <<" Ban muon nhap vao loai rau moi hay rau da co trong kho thuc an? " <<endl;
	cout <<" Bam '1' de nhap loai rau moi, '2' cho loai rau da co, Phim khac de quay tro lai munu truoc " <<endl;
	cout <<" \tLua chon cua ban: ";
	cin >> luachon;
	if (luachon == 1)
	{
	  Legume rau;
	  rau.valueLegume();
	  add_list_Legume (rau ,vege);
	}
	else if (luachon == 2)
	{
	  int sothutu;
	  float weight;
	  cout << " So thu tu cua rau muon nhap vao: ";
	  cin >> sothutu;
	  cout << " Khoi luong muon nhap them: ";
	  cin >> weight;
	  nhap_rau (sothutu, weight, vege);  
	}
	break;
      }
      case 5:
      {
	break;
      }
      default:
      {
	cout << "Nhap sai... Xin vui long nhap lai" << endl;
	break;
      }
    }
  }while (chose!=5);
}
