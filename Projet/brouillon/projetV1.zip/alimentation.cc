#include "alimentation.h"

Alimentation::Alimentation()
{
  cout << " == Constructeur par defaut: Alimentation" << endl;
  calorie = 0;
  nomAliment = "NULL";
}

Alimentation::~Alimentation()
{
  cout << " == Destructeur: Alimentation" << endl;
}



