#include "ouvrier.h"

Ouvrier::Ouvrier()
{
  cout << " == Constructeur par Defaut: Ouvrier" << endl;
  numEmploye++;
  numOuvrier = numEmploye;
  cout <<" Nhan vien se mang ma so: " << numOuvrier << endl;
  cout <<" Nhap ten cua nhan vien: ";
  cin.ignore();
  getline(cin,nomOuvrier);
  cout << "Ngay sinh: ";
  cin >> birthday;
  cout << "So dien thoai: ";
  cin >>tel;
  active = false;
  //nomOuvrier = "NULL";

}

Ouvrier::~Ouvrier()
{
  cout << " == Destructeur: Ouvrier" << endl;
}

Ouvrier::Ouvrier(string nom, int moi) // sau nay dua Cage thay moi vao de xu ly
{
  //cout << " == Constructeur avec parametre: Ouvrier" << endl;
  //nomOuvrier = nom;
  //numEmploye++;
  //numOuvrier = numEmploye;
  //numcage = moi;
  //active = true;
}

//Ouvrier::Ouvrier(const Ouvrier &o)
//{
 // numOuvrier = o.numOuvrier;
 // nomOuvrier = o.nomOuvrier;
//}
/*
Ouvrier &Ouvrier::operator= (const Ouvrier &o)
{
  if (this != &o)
    {
      numOuvrier = o.numOuvrier;
      nomOuvrier = o.nomOuvrier;
    }
  return *this;
}

ostream & operator<<(ostream &os, const Ouvrier &ouv)
{
  os << " - Nom de l'Ouvrier: " << ouv.getNomOuvrier() << endl;
  os << " - Son numero: " << ouv.getNumOuvrier() << endl;
  os << " - Cham soc Chuong: " << ouv.getChuong() <<endl;
  return os;
}*/

string Ouvrier::getNom()
{
  return nomOuvrier;
}
int Ouvrier::getNum()
{
  return numOuvrier;
}
int Ouvrier::getChuong()
{
  return numcage;
}
void Ouvrier::initialise_cage (int cage)
{
  numcage=cage;
  active = true;
}
void Ouvrier::set_passive()
{
    active=false;
}
bool Ouvrier::getActive()
{
  return active;
}
void Ouvrier::jeSuis()
{
  cout << "Son numero: " << numOuvrier << endl;
  cout << "Nom de l'Ouvrier: " << nomOuvrier << endl;
  cout << "Ngay sinh: " << birthday << endl;
  cout << "So dien thoai: " << tel << endl;
  if(active)
    cout << "Tinh trang: dang lam viec o chuong " << numcage <<endl;
  else
    cout << "Tinh trang: Chua phan cong chuong thu" << endl;

}
