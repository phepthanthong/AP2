#include "library.h"

using namespace std;

/*void menu_cage()
{
  cout << endl;
  cout << "\t1. Xem danh sach Cage " << endl;
  cout << "\t2. Xem thong tin Cage " << endl;
  cout << "\t3. Add cage" << endl;
  cout << "\t4. Delete Cage " << endl;
  cout << "\t5. Cho thu trong chuong an" << endl;
  cout << "\t6. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}*/

void workCage(list <Cage>& chuong, list <Animal> ani, list <Viande> &meat,list <Legume> &vege);