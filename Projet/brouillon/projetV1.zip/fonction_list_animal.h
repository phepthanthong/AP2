#ifndef HAMLIST_ANIMAL
#define HAMLIST_ANIMAL

#include <list>
#include <iostream>
#include <string.h>
#include "animal.h"
#include "cage.h"


using namespace std;



void show_list_Animal(list <Animal>  ani, list <Cage> chuong);
void show_info_Animal (list <Animal>  ani);
void add_list_Animal (Animal moi ,list <Animal> & ani, list <Cage> & chuong);
void delete_list_Animal (string maAnimal,list <Animal> &ani, list <Cage> & chuong);
void chang_place (list <Animal> &ani, list <Cage> & chuong);





#endif
