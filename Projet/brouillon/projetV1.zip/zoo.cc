#include "zoo.h"

Zoo::Zoo()
{
  cout << " == Constructeur par defaut: Zoo" << endl;
  nomZoo = "NULL";
  adrZoo = "NULL";
  phoneZoo = "NULL";
}



Zoo::~Zoo()
{
  cout << " == Destructeur: Zoo" << endl;
}

void Zoo::initialiseZoo()
{
  cout << "Nhap vao ten cua so thu: ";
  getline (cin,nomZoo);
  cout <<endl;
  cout << "Nhap vao dia chi cua so thu: ";
  getline (cin, adrZoo);
  cout << endl;
  cout << "Nhap vao so dien thoai: ";
  getline (cin, phoneZoo);
  cout << endl;
}

void Zoo::showZoo()
{
  cout << "ten cua so thu: " << nomZoo << endl;
  cout << "dia chi cua so thu: " <<adrZoo << endl;
  cout << "so dien thoai: " << phoneZoo << endl;
}