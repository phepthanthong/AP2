#include "animal_lion.h"

Lion::Lion()
{
  cout << " == Constructeur par defaut: Lion" << endl;
  numAnimal++;
  
  codeAnimal="A-C-";
  codeAnimal.append(static_cast<ostringstream*>( &(ostringstream() << numAnimal) )->str());
  type = "LION";
  quelType = loai_thu();
}

Lion::~Lion()
{
  cout << " == Destructeur: Lion" << endl;
}

void Lion::initialise()
{
  cout << endl;
  cout << "Ma so cua con su tu: " << codeAnimal << endl;
  cout << "Nhap ten cua con su tu" << endl;
  cin.ignore();
  getline(cin, nomAnimal);
  cout << "Chung loai: " << quelType << endl;
  cout << "la con: " << type << endl;
  cout << "Sa date de naissance: " ;
  cin.ignore();
  getline(cin, dateNais);
}
