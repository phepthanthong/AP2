#include "carnivore.h"

Carnivore::Carnivore()
{
  cout << " == Constructeur par defaut: Carnivore" << endl;
}

Carnivore::~Carnivore()
{
  cout << " == Destructeur: Carnivore" << endl;
}

string Carnivore::loai_thu()
{
  name="CARNIVORE";
  return name;
}