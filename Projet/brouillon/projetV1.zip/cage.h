#ifndef CAGE_H
#define CAGE_H
#include "animal.h"
#include "fonction_list_meat.h"
#include "fonction_list_vege.h"
#include <iostream>
#include <string>

using namespace std;

class Cage {
 private:
  string maCage;
  string type;
  string chungloai;
protected:
  static int numCage;
  
 public:
  Cage();
  ~Cage();
 
  void faireManger(list <Viande> & meat, list <Legume> & vege);
  string get_numCage();
  void setType(string type);
  string getType();
  string getChungloai();
  void setChungloai(string cl);
  void showCage();
  //void compterAnimaux();
  
};

#endif
