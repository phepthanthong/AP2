#ifndef OUVRIER_H
#define OUVRIER_H

#include <iostream>
#include <string>
#include "employe.h"

using namespace std;

class Ouvrier: public Employe {
 private:
  string nomOuvrier;
  int numOuvrier;
  int numcage;
  string birthday;
  string tel;
  bool active;
    
 public:
  Ouvrier();
  ~Ouvrier();
  Ouvrier(string nom, int moi); // sau do dua Cage numcage vao de xu ly

  void initialise_cage (int cage);
  void set_passive();
  bool getActive();
  string getNom();
  int getNum();
  int getChuong();

  void jeSuis();

};

#endif
  
