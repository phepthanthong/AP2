#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
#include <string>
#include <sstream>
//#include "Date.h"
using namespace std;

class Animal {
 protected:
  string nomAnimal;
  string dateNais;
  string codeAnimal;
  string quelType; // chung loai gi? vi du thu an con, an thit
  string type; // loai thu gi? vi du lion, tiger
  string cage;

  static int numAnimal;

 public:
  Animal();
  ~Animal();
  Animal &operator= (const Animal &ani);
  string getNomAnimal();
  string getNumero();
  string getChungloai();
  string getType();
  string getCage();
  void change_Cage(string maCage);

  void parler();


};

#endif  

