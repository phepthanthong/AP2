#include "fonction_list_vege.h"


/*======================= list rau =======*/
void show_list_Legume(list <Legume>  vegetable)
{
  list<Legume>::iterator it_Legume;
  if(vegetable.size()==0)
    cout << "khong co rau"<< endl;
  else
  {
    int sothutu=1;
    for(it_Legume = vegetable.begin(); it_Legume != vegetable.end(); it_Legume++)
    {
      cout << sothutu << ")\t";
      (*it_Legume).show_info();
      sothutu++;
    }
  }
}

void add_list_Legume (Legume moi ,list <Legume> & vegetable)
{
  vegetable.push_back(moi);
  cout << "Nhap rau moi thanh cong" <<endl;
}

void nhap_rau (int vitri, float khoiluong, list <Legume> & vegetable)
{
  list<Legume>::iterator it_Legume;
  for(it_Legume = vegetable.begin(); it_Legume != vegetable.end(); it_Legume++)
    {
      vitri--;
      if (vitri==0)
      {
	(*it_Legume).importLegume(khoiluong);
	cout << "Ban da nhap thanh cong " <<endl;
	break;
      }
    }
    if (it_Legume == vegetable.end())
      cout << "Nhap sai" <<endl;
}
void xuat_rau (int vitri, float khoiluong, list <Legume> & vegetable)
{
  list<Legume>::iterator it_Legume;
  for(it_Legume = vegetable.begin(); it_Legume != vegetable.end(); it_Legume++)
    {
      vitri--;
      if (vitri==0)
      {
	if ((*it_Legume).get_quantityLegume() >= khoiluong)
	{
	  (*it_Legume).exportLegume(khoiluong);
	  cout << " Cho thu an thanh cong" <<endl;
	}
	else
	  cout << "Thuc an ban chon khong du khoi luong" << endl;
	(*it_Legume).exportLegume(khoiluong);
      }
    }
    if (it_Legume == vegetable.end())
      cout << "Nhap rau sai" <<endl;
}