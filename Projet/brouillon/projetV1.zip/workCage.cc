#include "workCage.h"


void workCage(list <Cage> &chuong, list <Animal> ani, list <Viande> &meat,list <Legume> &vege)
{
  char chose;
  list <Cage>::iterator it_Cage;
  system("clear");
  do
  {
    menu_cage();
    cin >> chose;
    switch (chose)
    {
      case '1':
      {
	if (chuong.size() == 0)
	  cout << "Chua co chuong nao" <<endl;
	else
	{
	  cout << "Co cac chuong: ";
	  for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	    cout << (*it_Cage).get_numCage() << "\t" ;
	}
	break;
      }
      case '2':
      {
	string maCage;
	cout <<"Nhap ma Cage muon xem thong tin chi tiet: " ;
	cin >> maCage;
	for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	{
	  if((*it_Cage).get_numCage() == maCage)
	  {
	    (*it_Cage).showCage();
	    break;
	  }
	}
	if (it_Cage == chuong.end())
	  cout <<"Khong co chuong ban can tim" <<endl;
	//show_Cage(maCage, chuong);
	break;
      }
      case '3':
      {
	Cage cg;
	chuong.push_back(cg);
	//add_list_Ouvrier(cg, chuong);
	break;
      }
      case '4':
      {
	string maCage;
	cout << "Ma Cage ban muon loai khoi danh sach: ";
	cin >> maCage;
	if(chuong.size()==0)
	  cout << "List Cage empty"<< endl;
	else
	{
	  for(it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	    {
	      if (maCage == (*it_Cage).get_numCage())
		{
		  chuong.erase(it_Cage);
		  cout << "Da xoa Cage thanh cong" <<endl;
		  break;
		}
	    }
	  if (it_Cage == chuong.end())
	    cout << "Khong co Cage ban can xoa " << endl;
	}
	break;
      }
      case '5':
      {
	string maCage;
	cout << "Ma Cage ban muon cho thuc an: ";
	cin.ignore();
	getline(cin, maCage);
	if(chuong.size()==0)
	  cout << "List Cage empty"<< endl;
	else
	{
	  for(it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	    {
	      if (maCage == (*it_Cage).get_numCage())
		{
		  (*it_Cage).faireManger(meat, vege); // bi sai cho nay
		  break;
		}
	    }
	  if (it_Cage == chuong.end())
	    cout << "Khong co Cage ban can tim " << endl;
	}
	break;
      }
      case '6':
      {
	/*string maCage1, maCage2;
	list <Cage>::iterator it_Cage2;
	cout << "Nhap vao ma 2 chuong ban can doi cho cac con thu" <<endl;
	cout <<"   Cage 1: ";
	cin.ignore();
	getline(cin, maCage1);
	cout <<"   Cage 2: ";
	cin.ignore();
	getline(cin, maCage2);
	for(it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	    {
	      if (maCage1 == (*it_Cage).get_numCage())
		{
		  for(it_Cage2 = chuong.begin(); it_Cage2 != chuong.end(); it_Cage2++)
		    if (maCage2 == (*it_Cage2).get_numCage())
		    {
		      (*it_Cage).changerAnimal(*it_Cage2);
		      break;
		    }
		}
	    }
	if (it_Cage == chuong.end())
	    cout << "Khong co Cage ban can doi cho Animal " << endl;*/
	
	break;
      }
      case '7':
      {
	break;
      }
      default:
      {
	cout << "Nhap sai... Xin vui long nhap lai" << endl;
	break;
      }
    }
  }while (chose != '7');
}

