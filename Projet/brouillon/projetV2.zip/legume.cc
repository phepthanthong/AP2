#include "legume.h"

Legume::Legume()
{
  calorieLegume = 0;
  nomLegume = "NULL";
}

Legume::~Legume(){}




void Legume::valueLegume()
{
  cout << "Enter name of the Legume: ";
  cin >> nomLegume;
  cout << "How much it content in calorie? : ";
  cin >> calorieLegume;
  cout << "Weight of the " << nomLegume << " ?: ";
  cin >> quantityLegume;
}

void Legume::show_info()
{
  cout << "\tNom de l'Aliment: " << nomLegume << endl;
  cout << "\tIl contient " << calorieLegume << " calorie" << endl;
  cout << "\tKhoi luong rau cu qua: "<< quantityLegume << "kg" <<endl; 
}

float Legume::get_quantityLegume()
{
  return quantityLegume;
}
void Legume::importLegume(float a)
{
  quantityLegume +=a;
}

void Legume::exportLegume(float a)
{
  quantityLegume -=a;
}