#include "animal.h"

int Animal::numAnimal = 0;
Animal::Animal(){}

Animal::~Animal(){}

string Animal::getNomAnimal()
{
  return nomAnimal;
}

string Animal::getNumero()
{
  return codeAnimal;
}
string Animal::getType()
{
  return type;
}
string Animal::getChungloai()
{
  return quelType;
}
string Animal::getCage ()
{
  return cage;
}
void Animal::change_Cage(string maCage)
{
  cage = maCage;
}

void Animal::parler()
{
  cout << endl;
  cout << "\t - Son numero: " << codeAnimal << endl;
  cout << "\t\t - Nom de l'animal: " << nomAnimal << endl;
  cout << "\t\t - Son type: " << type << endl;
  cout << "\t\t - Chung loai: " << quelType << endl;
  cout << "\t\t - Ngay sinh: " << dateNais << endl;
  cout << "\t\t - Chuong: " << cage << endl;
  cout << endl;
}

