#include "herbivore.h"

Herbivore::Herbivore(){}

Herbivore::~Herbivore(){}

string Herbivore::loai_thu()
{
  name="HERBIVORE";
  return name;
}
