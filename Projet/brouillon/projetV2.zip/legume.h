#ifndef LEGUME_H
#define LEGUME_H

#include <iostream>
#include <string>
#include "alimentation.h"
using namespace std;

class Legume: public Alimentation {
 private:
  string nomLegume;
  int calorieLegume;
  float quantityLegume;

 public:
  Legume();
  ~Legume();

  void valueLegume();
  float get_quantityLegume();
  void importLegume(float a);
  void exportLegume(float a);
  void show_info();

};

#endif
