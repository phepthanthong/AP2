#include "menu.h"

using namespace std;

void menu_main()
{
  cout << endl;
  cout << "\t1. Xem thong tin cua so thu " << endl;
  cout << "\t2. Xu ly cage " << endl;
  cout << "\t3. Xu ly Animal" << endl;
  cout << "\t4. Xu ly Alimentation " << endl;
  cout << "\t5. Xu ly Ouvrier " << endl;
  cout << "\t6. Clear screen" << endl;
  cout << "\t7. Thoat " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_cage()
{
  cout << endl;
  cout << "\t1. Xem danh sach Cage " << endl;
  cout << "\t2. Xem thong tin Cage " << endl;
  cout << "\t3. Add cage" << endl;
  cout << "\t4. Delete Cage " << endl;
  cout << "\t5. Cho thu trong chuong an" << endl;
  cout << "\t6. Clear screen" << endl;
  cout << "\t7. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_animal()
{
  cout << endl;
  cout << "\t1. Xem danh sach Animal " << endl;
  cout << "\t2. Xem thong tin theo Animal " << endl;
  cout << "\t3. Xem thong tin theo Cage " << endl;
  cout << "\t4. Add Animal" << endl;
  cout << "\t5. Delete Animal" << endl;
  cout << "\t6. Delete Animal trong Cage" << endl;
  cout << "\t7. Doi chuong cho Animal" << endl;
  cout << "\t8. Clear screen" << endl;
  cout << "\t9. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_alimentation()
{
  cout << endl;
  cout << "\t1. Xem danh sach Thit " << endl;
  cout << "\t2. Xem danh sach Rau " << endl;
  cout << "\t3. Nhap thit" << endl;
  cout << "\t4. Nhap rau" << endl;
  cout << "\t5. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_ouvrier()
{
  cout << endl;
  cout << "\t1. Xem danh sach Nhan vien" << endl;
  cout << "\t2. Xem thong tin chi tiet nhan vien " << endl;
  cout << "\t3. Add nhan vien moi" << endl;
  cout << "\t4. Delete Nhan Vien" << endl;
  cout << "\t5. Thiet lap noi lam viec cho nhan vien" << endl;
  cout << "\t6. Clear screen" << endl;
  cout << "\t7. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";
}

void menu_list_animal()
{
    cout << endl;
  cout << "\t1. Lion" << endl;
  cout << "\t2. Tiger " << endl;
  cout << "\t3. Elephant" << endl;
  cout << "\t4. Humain" << endl;
  cout << "\t5. Quay tro ve Menu chinh " << endl  << endl;
  cout << "\t\tLua chon cua ban: ";  
}