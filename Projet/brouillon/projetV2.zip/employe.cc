#include "employe.h"


int Employe::numEmploye = 0;
Employe::Employe(){}

Employe::~Employe(){}

string Employe::getNom(){}
string Employe::getNum(){}
void Employe::jeSuis(){}
