#ifndef VIANDE_H
#define VIANDE_H

#include <iostream>
#include <string>
#include "alimentation.h"
using namespace std;

class Viande: public Alimentation {
 private:
  string nomViande;
  int calorieViande;
  float quantityViande;

 public:
  Viande();
  ~Viande();
  void valueViande();
  float get_quantityViande();
  void importViande(float a);
  void exportViande(float a);
  void show_info();

};

#endif
