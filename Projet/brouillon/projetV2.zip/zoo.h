#ifndef ZOO_H
#define ZOO_H

#include <iostream>
#include <string>
using namespace std;


class Zoo {
 private:
  string nomZoo;
  string adrZoo;
  string phoneZoo;
  
 public:
  Zoo();
  ~Zoo();
void initialiseZoo();
void showZoo();

};

#endif
