#include "carnivore.h"

Carnivore::Carnivore(){}

Carnivore::~Carnivore(){}

string Carnivore::loai_thu()
{
  name="CARNIVORE";
  return name;
}