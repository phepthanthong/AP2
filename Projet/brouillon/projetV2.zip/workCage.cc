#include "workCage.h"


void workCage(list <Cage> &chuong, list <Animal> ani,
	      list <Viande> &meat,list <Legume> &vege, list <Ouvrier> &ouv)
{
  char chose;
  list <Cage>::iterator it_Cage;
  system("clear");
  do
  {
    menu_cage();
    cin >> chose;
    fflush(stdin);
    switch (chose)
    {
      case '1':
      {
	if (chuong.size() == 0)
	  cout << "Chua co chuong nao" << endl;
	else
	{
	  cout << "Co cac chuong: \n";
	  for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	  {
	    cout <<"\t\t\t" << (*it_Cage).get_numCage() << "\t" ;
	    if( (*it_Cage).get_number_Animal()==0) cout << "Empty \n";
	    else cout << "Da co Animal \n";
	  }
	}
	break;
      }
      case '2':
      {
	string maCage;
	cout << endl <<"Nhap ma Cage muon xem thong tin chi tiet: " ;
	cin >> maCage;
	for (it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	{
	  if((*it_Cage).get_numCage() == maCage)
	  {
	    (*it_Cage).showCage();
	    break;
	  }
	}
	if (it_Cage == chuong.end())
	  cout <<"Khong co chuong ban can tim" <<endl;
	break;
      }
      case '3':
      {
	Cage cg;
	chuong.push_back(cg);
	cout <<"Tao thanh cong Cage " << cg.get_numCage() <<endl;
	break;
      }
      case '4':
      {
	string maCage;
	cout << "Ma Cage ban muon loai khoi danh sach: ";
	cin >> maCage;
	if(chuong.size()==0)
	  cout << "List Cage empty"<< endl;
	else
	{
	  for(it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	    {
	      if (maCage == (*it_Cage).get_numCage())
		{
		  if ((*it_Cage).get_number_Animal()==0)
		  {
		    deactivate(ouv, maCage);
		    chuong.erase(it_Cage);
		    cout << "Da xoa Cage thanh cong" <<endl;
		  }
		  else
		    cout << "Chuong dang co Animal, khong huy duoc" << endl;
		  break;
		}
	    }
	  if (it_Cage == chuong.end())
	    cout << "Khong co Cage ban can xoa " << endl;
	}
	break;
      }
      case '5':
      {
	string maCage;
	cout << endl << "Ma Cage ban muon cho thuc an: ";
	cin.ignore();
	getline(cin, maCage);
	if(chuong.size()==0)
	  cout << "List Cage empty"<< endl;
	else
	{
	  for(it_Cage = chuong.begin(); it_Cage != chuong.end(); it_Cage++)
	    {
	      if (maCage == (*it_Cage).get_numCage())
		{
		  (*it_Cage).faireManger(meat, vege);
		  break;
		}
	    }
	  if (it_Cage == chuong.end())
	    cout << "Khong co Cage ban can tim " << endl;
	}
	break;
      }
      case '6':
      {
	system("clear");
	break;
      }
      case '7':
      {
	break;
      }
      default:
      {
	cout << "Nhap sai... Xin vui long nhap lai" << endl;
	break;
      }
    }
  }while (chose != '7');
}

