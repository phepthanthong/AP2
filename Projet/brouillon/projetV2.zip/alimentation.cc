#include "alimentation.h"

Alimentation::Alimentation()
{
  calorie = 0;
  nomAliment = "NULL";
}

Alimentation::~Alimentation(){}



