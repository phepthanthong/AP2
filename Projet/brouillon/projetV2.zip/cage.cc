#include "cage.h"

int Cage::numCage = 0;
Cage::Cage()
{
  numCage++;
  maCage = "C-";
  maCage.append(static_cast<ostringstream*>( &(ostringstream() << numCage) )->str());
  type="NULL";
  chungloai="NULL";
  number_Animal=0;
  take_care="NULL";

}

Cage::~Cage(){}
void Cage::set_numCage(string code) { maCage =code;}

void Cage::setZero() {  number_Animal=0; }

void Cage::increase() { number_Animal++; }

void Cage::decrease() { number_Animal--; }

int Cage::get_number_Animal() { return number_Animal; }

void Cage::set_number_Animal(int number) {number_Animal = number;}

void Cage::set_take_care(string nameNV)  { take_care = nameNV; }

string Cage::get_take_care() { return take_care; }
void Cage::faireManger(list <Viande> & meat, list <Legume> & vege)
{
  if (getChungloai()=="CARNIVORE")
  {
    int sothutu;
    float khoiluong;
    show_list_viande(meat);
    cout << "Nhap so thu tu: "; cin >> sothutu;
    cout << "Nhap vao khoi luong: "; cin >> khoiluong;
    xuat_thit (sothutu, khoiluong, meat);
  }
  else if (getChungloai()=="HERBIVORE")
    {
    int sothutu;
    float khoiluong;
    show_list_Legume(vege);
    cout << "Nhap so thu tu: "; cin >> sothutu;
    cout << "Nhap vao khoi luong: "; cin >> khoiluong;
    xuat_rau (sothutu, khoiluong, vege);
  }
  else
    cout << "Chuong khong co thu, khoi cho an" << endl;
}
string Cage::getChungloai()
{
  return chungloai;
}
void Cage:: setChungloai(string cl)
{
  chungloai=cl;
}
string Cage::get_numCage()
{
  return maCage;
}
void Cage::setType(string loai)
{
  type=loai;
}
string Cage::getType()
{
  return type;
}
void Cage::showCage()
{

  cout << "Numero de Cage: " << maCage << endl;
  if(type =="NULL")
    cout << "khong co con thu nao ca"<< endl;
  else
  {
    cout << "Cage dang chua: " << type << " co so luong: " << number_Animal << " con" << endl;
    
  }
  if (take_care !="NULL") cout << "Co nhan vien " << take_care <<  " cham soc" << endl;
  else cout << "Khong co nhan vien cham soc... ALERT" << endl;
  cout << endl;
}


